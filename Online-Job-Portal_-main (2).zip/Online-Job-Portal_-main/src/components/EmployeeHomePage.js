import Header from './Header'
import Wrapper from './Wrapper'
export default function EmployeeHomePage(p) {
    return (
        <>
        <Header isEmployer={false} />
        <Wrapper isEmployer={false} />
        </>
    )
};
